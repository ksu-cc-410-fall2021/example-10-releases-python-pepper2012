"""Test Package for Guessing Game.

Author: Micheal Pepper micpepper@ksu.edu
Version 0.1
"""
